<!DOCTYPE html>
<?php
$firsttime="0";
$tokenname = $tokensymbol = $tokensupply = $adminaccount = $superkey = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $tokenname = test_input($_POST["tokenname"]);
   $tokensymbol = test_input($_POST["tokensymbol"]);
   $tokensupply = test_input($_POST["tokensupply"]);
   $adminaccount = test_input($_POST["adminaccount"]);
   $superkey = test_input($_POST["superkey"]);
   $firsttime = test_input($_POST["firsttime"]);
   $confirm = test_input($_POST["comfirm"]);
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<?php
exec("sh /var/www/html/fb.sh \"$tokenname\" \"$tokensymbol\" \"$tokensupply\" \"$adminaccount\" \"$superkey\"",$res);
foreach($res as $key=>$value)
{
if(strpos($value,"fwbHash:")!==false)
  {
   if(preg_match('/0x(.*?)$/',$value,$match))
       $fwbhash=$match[0];
   } 
if(strpos($value,"contractAddress: ")!==false)
   {
    if(preg_match('/\"(.*?)\"/',$value,$match))
	$fwbaddr=$match[0];
    }
}


?>


  <head>
    <meta content="origin-when-cross-origin" name="referrer" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>CREATE TOKEN</title>

    <link rel="stylesheet" media="all" href="token.css" />


<script language="javascript">

function custom_close(){
  if (confirm("您确定要关闭本页吗？"))
    {window.opener=null;
      window.open('','_self');
      window.close();}
      else{}
    }

</script>


  </head>
  <body>
    

    <div class="topbar">
  <div class="page">
    <div class="topbar-container">
      <a class="topbar-logo topbar-logo-envato" ></a><h1><font face="verdana" color="#F8F8FF">创建TOKEN/CREATE TOKEN</font></h1>

      <div class="topbar-content">
        

      </div>
    </div>
  </div>
</div>


    <div class="page">
      
      <div role="main" class="main">
        <script>sso.init = "username_recovery/new"</script>


<div class="box-new">
  

    <?php
    if(strlen($fwbhash)==0 || strlen($fwbaddr)==0) {
          echo       " <h1 class=\"box-heading\">抱歉！创建TOKEN失败</h1><p>请用HASH重新查询部署情况或重新提交参数！ </p>";
    }
    else {
           echo       " <h1 class=\"box-heading\">恭喜！创建TOKEN成功</h1><p>请记录如下token的信息尤其保存好合约地址！ </p>";
         }
echo "TOKEN合约哈希:";
echo "\n<br>\"";
echo strlen($fwbhash)==0?"没生成正确的HASH值":$fwbhash;
echo "\"<br>";
echo "部署合约地址:";
echo "\n<br>";
echo strlen($fwbaddr)==0?"\"没获得正确的合约地址\"":$fwbaddr;
echo "\n<br>";
echo "\n<br>";
echo "TOKEN名称:".$tokenname;
echo "\n<br>";
echo "TOKEN简称:".$tokensymbol;
echo "\n<br>";
echo "TOKEN数量:".$tokensupply;
echo "\n<br>";
echo "管理地址:".$adminaccount;
echo "\n<br>";
echo "\n<br>";
echo "请认真保存以上信息，通过钱包在管理地址上可以查看创建的Token总额！";
echo "\n<br>";
echo "\n<br>";
echo "\n<br>";

echo "<input type=\"button\" name=\"commit\" onclick=\"custom_close();\" value=\"确认已经记录以上信息！/See you later！\" />";

    ?>



</form></div>
      </div>


<hr>
    </div>

  
    

  </body>
</html>
