<!DOCTYPE html>
<head>
    <meta content="origin-when-cross-origin" name="referrer" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>CREATE TOKEN</title>
    <script type="text/javascript" src="jquery.js"></script>
    <link rel="stylesheet" media="all" href="token.css" />
<?php
// define variables and set to empty values
// 
$firsttime="0";
$tokenname = $tokensymbol = $tokensupply = $adminaccount = $superkey = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $tokenname = test_input($_POST["tokenname"]);
   $tokensymbol = test_input($_POST["tokensymbol"]);
   $tokensupply = test_input($_POST["tokensupply"]);
   $adminaccount = test_input($_POST["adminaccount"]);
   $superkey = test_input($_POST["superkey"]);
   $firsttime = test_input($_POST["firsttime"]);
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
</head>
<body>
    <div class="header">
        <div class="head-con m-warp">创建TOKEN/CREATE TOKEN</div>
    </div>
<?php if (strcmp($firsttime,"0")==0): ?>
    <form id="form1" action="./fb.php" accept-charset="UTF-8" method="post">
    <input type="hidden" name="firsttime" value="1">
    <div class="content active m-warp">
        <div class="con-box m-wars " style="width: 600px;">
            <div class="titile" style="text-align: center;">创建TOKEN</div>
            <div class="form-box hasname">
                <div class="form-item">
<style type="text/css">

</style>
                    <div class="titname">名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称</div>
                    <div class="input-box">
                        <input id="tokenname" type="text" name="tokenname" placeholder="TOKEN名称/Token Name">
                    </div>
                    <div class="err-tis">会员名为5-25字符，需要字母、数字或空格组成</div>
                </div>
                <div class="form-item">
                    <div class="titname">简&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称</div>
                    <div class="input-box">
                        <input id="tokensymbol" type="text" name="tokensymbol" placeholder="TOKEN简称/Token Symbol">
                    </div>
                    <div class="err-tis">大写字母不超过6个字符</div>
                </div>
                <div class="form-item">
                    <div class="titname">数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;量</div>
                    <div class="input-box">
                        <input id="tokensupply" type="number" name="tokensupply" placeholder="TOKEN数量/Token Supply">
                    </div>
                    <div class="err-tis">请输入数量</div>
                </div>
                <div class="form-item">
                    <div class="titname">管理账号</div>
                    <div class="input-box">
                        <input id="adminaccount" type="text" name="adminaccount" placeholder="管理地址/Admin Account">
                    </div>
                    <div class="err-tis">管理账号格式错误<!-- 由0x开头16进制40个字符组成 --></div>
                </div>
                <div class="form-item">
                    <div class="titname">超级口令</div>
                    <div class="input-box">
                        <input id="superkey" type="text" name="superkey" placeholder="超级秘钥/Super Password">
                    </div>
                    <div class="err-tis"></div>
                </div>
                <div class="form-item">
                <div class="confirm-btn j-comfirm" onclick="comfirm()">确认提交</div>
                </div>
            </div>
        </div>
    </div>
    </form>
<?php else: ?>
    <form id="form1" action="./fb_confirm.php" accept-charset="UTF-8" method="post">
    <div class="input-box" style="display: none">
        <input type="hidden" name="firsttime" value="0">
        <input id="tokenname" type="text" name="tokenname"  value="<?php  echo $tokenname; ?>">
        <input id="tokensymbol" type="hidden" name="tokensymbol" value="<?php  echo $tokensymbol; ?>">
        <input id="tokensupply" type="hidden" name="tokensupply" value="<?php  echo $tokensupply; ?>">
        <input id="adminaccount" type="hidden" name="adminaccount" value="<?php  echo $adminaccount; ?>">
        <input id="superkey" type="hidden" name="superkey" value="<?php  echo $superkey; ?>">
    </div>
        <div class="confirm-box content active m-warp sss">
        <div class="confirm-con m-wars w700">
            <div class="titile" style="line-height:50px;padding-top: 10px; ">再次确认</div>
            <div class="confirm-decs" style="color: #f7594d;padding-bottom: 10px;">请仔细检查输入的参数</div>
            <div class="confirm-form-box">
                <div class="confirm-item">
                    <span class="confirm-item-title">TOKEN名称：</span>
                    <span class="confirm-item-con name"><?php  echo $tokenname; ?></span>
                </div>
                <div class="confirm-item">
                    <span class="confirm-item-title">TOKEN简称：</span>
                    <span class="confirm-item-con symbol"><?php  echo $tokensymbol; ?></span>
                </div>
                <div class="confirm-item">
                    <span class="confirm-item-title">TOKEN数量：</span>
                    <span class="confirm-item-con supply"><?php  echo $tokensupply; ?></span>
                </div>
                <div class="confirm-item">
                    <span class="confirm-item-title">管理地址：</span>
                    <span class="confirm-item-con account"><?php  echo $adminaccount; ?></span>
                </div>
                <div class="confirm-item">
                    <span class="confirm-item-title">超级口令：</span>
                    <span class="confirm-item-con password"><?php  echo $superkey; ?></span>
                </div>
                <div class="btbt">
                  <div class="confirm-btn j-cancel cancel" onclick="go.history(-1)">取消/Cancel</div>
                  <div class="confirm-btn j-comfirm" onclick="openpopup()">再确认并创建/Comfirm&amp;Create Token</div>
                </div>
            </div>
        </div>
    </div>
    </form>
<?php endif; ?>
<!--     <div class="footer m-warp">
        <p>京ICP备11017824号-4 / 京ICP证130164号 北京市公安局朝阳分局备案编号:110105000501</p>
        <p>Copyright © 2016-2017 Fanwe 中文 English</p>
    </div> -->

    <div id="popup" class="popup" style="position: fixed;width: 100%;height: 100%;top: 0;
left: 0;right: 0;bottom: 0;background: rgba(0,0,0,0.6);z-index: 9;display: none;">    
    <div class="confirm-box content active m-warp sss" style="width: 500px;">
        <div class="confirm-con m-wars">
            <div class="titile" style="line-height:50px;padding-top: 10px; ">还剩<span id="timer">20</span>秒</div>
            <div class="confirm-decs" style="color: #f7594d;padding-bottom: 10px;">创建Token的时间大约需要20秒,请您耐心等待哦</div>
            <div class="confirm-form-box" style="height: 64px;">
                <div class="btbt" style="text-align: right;">
                    <!-- <a id="closepopup" style="display: none;" class="confirm-btn cancel" href="/fb.php">重新创建</a> -->
                    <div id="closepopup" style="display: none;" class="confirm-btn cancel" onclick="closepopup()">关闭</div>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
<script type="text/javascript">
$(function(){
    $('.j-cancel').on('click',function(){
        window.history.go(-1);
    });
});

function comfirm(){
    var name = $('.input-box').find('input[name="tokenname"]');
    var symbol = $('.input-box').find('input[name="tokensymbol"]');
    var supply = $('.input-box').find('input[name="tokensupply"]');
    var account = $('.input-box').find('input[name="adminaccount"]');
    var password = $('.input-box').find('input[name="superkey"]');
    var symbol_val =symbol.val();
    var supply_val =supply.val();
    var account_val =account.val();
    var reg=/^[a-zA-Z0-9\s]*$/gi;
    var regs=/^[0-9a-fA-F]{40}$/gi;
    console.log(name.val());
    
    if(trim(name.val())==''){
        var err_tis= $(name).parent().next();
        $(name).parents(".form-item").addClass('error');
        $(name).focus();
        $(err_tis).html('请输入TOKEN名称');
        return false;
    }else{
        $(name).parents(".form-item").removeClass('error');
    }
    if(reg.test(name.val())){
    }else {
        var err_tis= $(name).parent().next();
        $(name).parents(".form-item").addClass('error');
        $(name).focus();
        $(err_tis).html('只能是字母或数字组成');
        return false;
    }
    if(name.val().length<5||name.val().length>25){
        var err_tis= $(name).parent().next();
        $(name).parents(".form-item").addClass('error');
        $(name).focus();
        $(err_tis).html('会员名为5-25字符，需要字母或数字组成');
        return false;
    }
    if(symbol.val()==''){
        var err_tis= $(symbol).parent().next();
        $(symbol).parents(".form-item").addClass('error');
        $(symbol).focus();
        $(err_tis).html('请输入TOKEN简称');
        return false;
    }else{
        $(symbol).parents(".form-item").removeClass('error');
    }
    if (/^[A-Z0-9]+$/.test(symbol_val)){ 
    }else {
        var err_tis= $(symbol).parent().next();
        $(symbol).parents(".form-item").addClass('error');
        $(symbol).focus();
        $(err_tis).html('只能输入大写字母');
        return false; 
    }
    if(symbol_val.length<7){

    }else{
        var err_tis= $(symbol).parent().next();
        $(symbol).parents(".form-item").addClass('error');
        $(symbol).focus();
        $(err_tis).html('不能超过6个字符');
        return false; 
    }
    if(supply.val()==''){
        var err_tis= $(supply).parent().next();
        $(supply).parents(".form-item").addClass('error');
        $(supply).focus();
        $(err_tis).html('请输入数量');
        return false;
    }else{
        $(supply).parents(".form-item").removeClass('error');
    }
    

    if(/^[0-9]+$/.test(supply_val)){
    }
    else{
        var err_tis= $(supply).parent().next();
        $(supply).parents(".form-item").addClass('error');
        $(supply).focus();
        $(err_tis).html('请输入正确的数量');
        return false;
    }
    if(account.val()==''){
        var err_tis= $(account).parent().next();
        $(account).parents(".form-item").addClass('error');
        $(account).focus();
        $(err_tis).html('请输入管理地址');
        return false;
    }else{
        $(account).parents(".form-item").removeClass('error');
    }
    var accountop = account_val.substr(0, 2);
    if(accountop!='0x'){
        var err_tis= $(account).parent().next();
        $(account).parents(".form-item").addClass('error');
        $(account).focus();
        $(err_tis).html('请输入0x开头 16进制40位的字符');
        return false;
    }else{
        $(account).parents(".form-item").removeClass('error');
    }
    
    if(account.val().length!=42){
        var err_tis= $(account).parent().next();
        $(account).parents(".form-item").addClass('error');
        $(account).focus();
        $(err_tis).html('请输入16进制40个的字符');
        return false;
    }else{
        $(account).parents(".form-item").removeClass('error');
    }
    var accounts = account_val.slice(2, account_val.length);
    if(regs.test(accounts)){
        $(account).parents(".form-item").removeClass('error');
    }else {
        var err_tis= $(account).parent().next();
        $(account).parents(".form-item").addClass('error');
        $(account).focus();
        $(err_tis).html('请输入16进制的字符');
        return false;
    }
    if(password.val()==''){
        var err_tis= $(password).parent().next();
        $(password).parents(".form-item").addClass('error');
        $(password).focus();
        $(err_tis).html('请输入超级秘钥');
        return false;
    }else{
        $(password).parents(".form-item").removeClass('error');
    }
    $('.name').html(name.val());
    $('.symbol').html(symbol.val());
    $('.supply').html(supply.val());
    $('.account').html(account.val());
    $('.password').html(password.val());
    $('.content').removeClass('active');
    $('.footer').addClass('active');
    console.log($(this).parents('.content'));
    $('.confirm-box').addClass('active');
    document.getElementById("form1").submit();
}
function trim(str){
    return str.replace(/\s|\xA0/g,"");    
}
function closepopup(){
    $("#closepopup").hide();
    $("#popup").hide();
    window.clearTimeout(timer1all);
}
function openpopup(){
    $("#closepopup").hide();
    $("#popup").show();
    countdown=20;
    settime(20);
    comfirm();
}
var timer1all;
var countdown=20; 
function settime(){ 
if (countdown == 0) { 
    window.clearTimeout(timer1all); 
    countdown = 0; 
    $("#timer").html(0);
    $("#closepopup").show();
} else { 
    $("#timer").html(countdown);
    countdown--; 
    var timer1=setTimeout(function(){ settime();},1000);
    timer1all=timer1;
} 
} 

</script>
</html>
