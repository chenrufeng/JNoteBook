/usr/bin/gethfw attach ipc:/node/node8001/geth.ipc << EOF 
eth.getTransactionReceipt("$1");
admin.sleep(5);
EOF

