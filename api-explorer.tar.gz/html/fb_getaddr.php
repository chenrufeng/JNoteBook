<!DOCTYPE html>
<?php

$fwbhash="";
$fwbaddr="";

if ($_SERVER["REQUEST_METHOD"] == "GET") {
   $fwbhash = test_input($_GET["hash"]);
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}

exec("sh /var/www/html/fb_getaddr.sh \"$fwbhash\" ",$res);
foreach($res as $key=>$value)
{

if(strpos($value,"contractAddress: ")!==false)
   {
    if(preg_match('/\"(.*?)\"/',$value,$match))
	$fwbaddr=$match[0];
    }
}


?>


  <head>
    <meta content="origin-when-cross-origin" name="referrer" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>CREATE TOKEN</title>

    <link rel="stylesheet" media="all" href="token.css" />

  <script>sso.init = "username_recovery/new"</script>
<script language="javascript">

function custom_close(){
  if (confirm("您确定要关闭本页吗？"))
    {window.opener=null;
      window.open('','_self');
      window.close();}
      else{}
    }

</script>


  </head>


  <body>
    <div class="header">
        <div class="head-con m-warp">搜索合约地址/SEARCH CONTRACT ADDRESS</div>
    </div>


 
<?php if(strlen($fwbaddr)==0): ?>
    <div class="confirm-box content active m-warp sss">
    <div class="confirm-con m-wars w700">
        <div class="titile">抱歉！在最新区块上没有查到相应的合约！</div>
        <div class="confirm-decs" style="">请等待一些时间再次查询或咨询管理员！！</div>
        <div class="confirm-form-box">
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN合约哈希：</span>
                <span class="confirm-item-con name"><?php  echo $fwbhash; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">部署合约地址：</span>
                <span class="confirm-item-con symbol">没获得正确的合约地址</span>
            </div>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <div class="btbt">
            <a class="confirm-btn cancel" href="/fb.php">重新创建TOKEN</a>
              <div class="confirm-btn" onclick="custom_close();">确认已经记录以上信息！并关闭窗口</div>
            </div>
        </div>
    </div>
    </div>
<?php else: ?>
    <div class="confirm-box content active m-warp sss">
    <div class="confirm-con m-wars w700">
        <div class="titile">恭喜！在最新区块上查询到相应的合约</div>
        <div class="confirm-decs" style="">请记录如下token的信息尤其保存好合约地址！ </div>
        <div class="confirm-form-box">
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN合约哈希：</span>
                <span class="confirm-item-con name"><?php  echo $fwbhash; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">部署合约地址：</span>
                <span class="confirm-item-con symbol"><?php  echo $fwbaddr; ?></span>
            </div>
            <br>
            <br>
            <br>

            <div class="confirm-decs">请认真保存以上信息，通过钱包在管理地址上可以查看创建的Token总额！</div>
            <div class="btbt">
            <a class="confirm-btn j-cancel cancel" href="/fb.php">再创建一个TOKEN</a>
              <div class="confirm-btn " onclick="custom_close();">确认已经记录以上信息！并关闭窗口</div>
            </div>
        </div>
    </div>
    </div>
<?php endif; ?>


  
<!--     <div class="footer m-warp">
        <p>京ICP备11017824号-4 / 京ICP证130164号 北京市公安局朝阳分局备案编号:110105000501</p>
        <p>Copyright © 2016-2017 Fanwe 中文 English</p>
    </div> -->

</body>
</html>