<?php
require_once('fwl.php');
$url =  "http://172.16.13.190";
$port = 8545;
$flag = 1;
$fwl = new fwl($url, $port);
$address = "0x7ca4541f9c9fe5ca3835e4a2683ef0a2eff1437b";
$from = $address;
$to = "0xbc9638f8c8a8ddae1c59663e6342023e3844e847";


function  getAddressBlocks($address,$flag) {
$mongo   = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
$filter =  [ '$or' => [['from' => $address],
           ['to' => $address]]];
$options = array(    
	"sort" => array("blockNumber" => $flag,),
);
$query = new MongoDB\Driver\Query($filter, $options);
$rows = $mongo->executeQuery('blockDB.Transaction', $query);
foreach($rows as $r){   
     echo "blocknumber=".$r->blockNumber;
}
return 0;
}

if($sort =="desc") {
	$flag = -1;
}

getAddressBlocks($address,$flag);







