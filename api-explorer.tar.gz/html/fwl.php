<?php

class fwl
{
    var $url = null;
    var $port = null;
    var $id = 0;
    var $debug=false;


    function __construct($url, $port){
        //TODO VALIDIATE / CHECK IS IT LIVE
        $this->url = $url;
        $this->port = $port;
    }


    //Supplimental functions
    function fwl_to_wei($fwl){
        return $fwl * 1000000000000000000;
    }

    function wei_to_eth($fwl){
        return $fwl / 1000000000000000000;
    }

    //ETH Functions - RPC API
    function curl_data($method, $parameters="", $state =null, $boolean=null){
		
	$flag = false;
	$showflag=true;
    
        if(!empty($state)) {
            //prepare state
            switch ($state) {
                case 0:
                    $parameters .= '","earliest';
                    break;
                case 1:
                    $parameters .= '","latest';
                    break;
                case 2:
                    $parameters .= '","pending';
                    break;
		case 3:
		    $flag = true;
		    break;
		case 4:
		    $showflag=false;
		    break;
            }

        }
        if(!empty($boolean)) {
            if ($boolean) {
                $insert = ",true";
            } else {
                $insert = ", false";
            }
        } else {
            $insert = "";
        }

		if($flag)
			$data = '{"jsonrpc":"2.0","method":"'.$method.'","params":['.$parameters.'],"id":'.$this->id.'}';
		
		else {
			
			if(!empty($parameters) AND substr($parameters,0,1)=="{") {
				$data = '{"jsonrpc":"2.0","method":"'.$method.'","params":['.$parameters.'],"id":'.$this->id.'}';
			} else {
				$data = '{"jsonrpc":"2.0","method":"' . $method . '","params":["' . $parameters . '"' . $insert . '],"id":' . $this->id . '}';
			}
		
		}
		
        $ch = curl_init($this->url.":".$this->port);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	'Content-Type: application/json',
	'Content-Length: ' . strlen($data))
	);
        $result = curl_exec($ch);
		
        curl_close($ch);
        if($this->debug) {
            echo "Request: $data \n";
            echo "Result: $result \n";
        }

        $result = json_decode($result);


		if($showflag==true)
		{
			if(array_key_exists("error",$result)==true)
				echo '{"status":"0","message":'.json_encode($result->error->message).',"result":[]}';
			if(array_key_exists("result",$result)==true)
				echo '{"status":"1","message":"OK","result":'.json_encode($result->result).'}';
		}

        $this->id++;


        return $result;
    }
	
	//ETH Functions - RPC API
    function curl_data_block_result($method, $parameters="", $state =null, $boolean=null){
		
	$flag = false;
	$showflag=true;
    
        if(!empty($state)) {
            //prepare state
            switch ($state) {
                case 0:
                    $parameters .= '","earliest';
                    break;
                case 1:
                    $parameters .= '","latest';
                    break;
                case 2:
                    $parameters .= '","pending';
                    break;
		case 3:
		    $flag = true;
		    break;
		case 4:
		    $showflag=false;
		    break;
            }

        }
        if(!empty($boolean)) {
            if ($boolean) {
                $insert = ",true";
            } else {
                $insert = ", false";
            }
        } else {
            $insert = "";
        }

		if($flag)
			$data = '{"jsonrpc":"2.0","method":"'.$method.'","params":['.$parameters.'],"id":'.$this->id.'}';
		
		else {
			
			if(!empty($parameters) AND substr($parameters,0,1)=="{") {
				$data = '{"jsonrpc":"2.0","method":"'.$method.'","params":['.$parameters.'],"id":'.$this->id.'}';
			} else {
				$data = '{"jsonrpc":"2.0","method":"' . $method . '","params":["' . $parameters . '"' . $insert . '],"id":' . $this->id . '}';
			}
		
		}
		
        $ch = curl_init($this->url.":".$this->port);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
	'Content-Type: application/json',
	'Content-Length: ' . strlen($data))
	);
        $result = curl_exec($ch);
		
        curl_close($ch);
        if($this->debug) {
            echo "Request: $data \n";
            echo "Result: $result \n";
        }

        $result = json_decode($result);


		if($showflag==true)
		{
			if(array_key_exists("result",$result)==true) {
				//$jsonstr = json_encode($result->result);
			    //echo substr($jsonstr,1,strlen($jsonstr)-1);
				//return $result->result;
			}
		}
        $this->id++;
        return $result;
    }
	

    function check_modules(){
        $method = "modules";
        $resp = $this->curl_data($method);
        return $resp["result"];
    }

    function admin_peers(){
        $method = "admin_peers";
        $resp = $this->curl_data($method);
        return $resp["result"];
    }

    function admin_nodeInfo(){
        $method = "admin_nodeInfo";
        $resp = $this->curl_data($method);
        return $resp["result"];
    }

    function admin_addPeer($enode, $ip){
        $method = "admin_addPeer";

        //STRIP " if left in.
        $enode = str_replace('"',"",$enode);

        //Fill the IP in
        $parameters = str_replace("[::]",$ip,$enode);

        $resp = $this->curl_data($method, $parameters);
        return $resp["result"];
    }

    function fwl_accounts(){
        $method = "fwl_accounts";
        $resp = $this->curl_data($method);
//        return $resp->result;
          return $resp;
    }

    function fwl_blockNumber(){
        $method = "fwl_blockNumber";
        $resp = $this->curl_data($method);;
        //return hexdec($resp["result"]);
          return $resp;
    }

    function fwl_getBalance($account, $state=1){
        $method = "fwl_getBalance";
        $resp = $this->curl_data($method, $account, $state);
        //return hexdec($resp->result);
        return $resp;
    }

    function fwl_getStorageAt($param1="",$param2="",$param3=""){
        $method = "fwl_getStorageAt";
        $param = $param1.'", "'.$param2.'", "'.$param3;
        $resp = $this->curl_data($method, $param);
        return $resp;
    }
    function fwl_getTransactionCount($param1="",$param2=""){
        $method = "fwl_getTransactionCount";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method, $param);
        return $resp;
    }

    function fwl_coinbase(){
        $method = "fwl_coinbase";
        $resp = $this->curl_data($method);
        return $resp;
    }

	
    function fwl_mining($showflag=true){
        $method = "fwl_mining";
	if($showflag==true)
        $resp = $this->curl_data();
	else
        $resp = $this->curl_data($method,"",4);

        return $resp;
    }

    function fwl_gasPrice(){
        $method = "fwl_gasPrice";
        $resp = $this->curl_data($method);
        //return hexdec($resp["result"]);
        return $resp;
    }

    function fwl_hashrate(){
        if($this->fwl_mining(false)) {
            $method = "fwl_hashrate";
            $resp = $this->curl_data($method);
            //return hexdec($resp["result"]);
	    return $resp;
        } else {
            return "This node is not mining -> Hash rate: 0";
        }
    }

    function net_peerCount(){
        $method = "net_peerCount";
        $resp = $this->curl_data($method);
        //return hexdec($resp["result"]);
	return $resp;
    }

    function fwl_syncing(){
        $method = "fwl_syncing";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function admin_datadir(){
        $method = "admin_datadir";
        $resp = $this->curl_data($method);
        return $res["result"];
    }




    function personal_listAccounts(){
        $method = "personal_listAccounts";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function personal_newAccount($key){
        $method = "personal_newAccount";
        $resp = $this->curl_data($method, $key);
        return $resp->result;
    }

    function personal_importRawKey($keydata,$passphrase){
        $method = "personal_importRawKey";
        $parameters = $keydata.'", "'.$passphrase;
        $resp = $this->curl_data($method, $parameters);
        return $resp;
    }

    function personal_unlockAccount($account, $key, $time=""){
        $method = "personal_unlockAccount";
        $parameters = $account.'", "'.$key;
        if(!empty($time)) {
            $parameters .= '", "'.$time;
        }

        $resp = $this->curl_data($method, $parameters);
        //return $resp->result;
        return $resp;

    }

    function personal_lockAccount($account){
        $method = "personal_lockAccount";
        $resp = $this->curl_data($method, $account);
        return $resp;
    }

    function txpool_content(){
        $method = "txpool_content";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function txpool_inspect(){
        $method = "txpool_inspect";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function txpool_status(){
        $method = "txpool_status";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function net_version(){
        $method = "net_version";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function net_listening(){
        $method = "net_listening";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function fwl_protocolVersion(){
        $method = "fwl_protocolVersion";
        $resp = $this->curl_data($method);
        //return hexdec($resp["result"]);
        return $resp;
    }

    function web3_clientVersion(){
        $method = "web3_clientVersion";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function fwl_getBlockTransactionCountByHash($block_hash){
        $method = "fwl_getBlockTransactionCountByHash";
        $resp = $this->curl_data($method, $block_hash);
        return $resp;
    }

    function fwl_getBlockTransactionCountByNumber($block_number){
        $method = "fwl_getBlockTransactionCountByNumber";
        $resp = $this->curl_data($method, $block_number);
        return $resp;
    }

    function fwl_getUncleCountByBlockHash($block_hash){
        $method = "fwl_getUncleCountByBlockHash";
        $resp = $this->curl_data($method, $block_hash);
        return $resp;
    }
    
    function fwl_getUncleByBlockHashAndIndex($param1,$param2){
        $method = "fwl_getUncleByBlockHashAndIndex";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method,$param);
        return $resp;
    }
    function fwl_getUncleByBlockNumberAndIndex($param1,$param2){
        $method = "fwl_getUncleByBlockNumberAndIndex";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method,$param);
        return $resp;
    }

    function fwl_getUncleCountByBlockNumber($block_number){
        $method = "fwl_getUncleCountByBlockNumber";
        $resp = $this->curl_data($method, $block_number);
        return $resp;
    }

    function fwl_getCode($param1,$param2){
        $method = "fwl_getCode";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method,$param);
        return $resp;
    }
    function fwl_sign($param1,$param2){
        $method = "fwl_sign";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method,$param);
        return $resp;
    }

    function fwl_getBlockByHash($block_hash, $detailed="true"){
        $method = "fwl_getBlockByHash";
        $resp = $this->curl_data($method, $block_hash, null, $detailed);
        return $resp;
    }
//EDIT by KNB	
	function fwl_txlist($address,$startblock,$endblock,$latestblock,$page=0,$offset=0){
        $method = "fwl_txlist";
		$params = $startblock.', "'.$endblock.'", "'.$latestblock.'", "'.$address.'",'.$page.','.$offset;
        //$params = '{"startblock":'.$startblock.', "endblock":'.$endblock.', "address":"'.$address.'"}';
        $resp = $this->curl_data($method, $params,3);
        return $resp->result;
    }
	
	function fwl_tokentx($address,$startblock,$endblock,$latestblock,$page=0,$offset=0){
        $method = "fwl_tokentx";
		$params = $startblock.', "'.$endblock.'","'.$latestblock.'", "'.$address.'",'.$page.','.$offset;
        //$params = '{"startblock":'.$startblock.', "endblock":'.$endblock.', "address":"'.$address.'"}';
        $resp = $this->curl_data($method, $params,3);
        return $resp->result;
    }
	
	function fwl_txlist2($address,$startblock,$endblock,$latestblock,$page=0,$offset=0){
        $method = "fwl_txlist";
		$params = $startblock.', "'.$endblock.'", "'.$latestblock.'", "'.$address.'",'.$page.','.$offset;
        //$params = '{"startblock":'.$startblock.', "endblock":'.$endblock.', "address":"'.$address.'"}';
        $resp = $this->curl_data_block_result($method, $params,3);
        return $resp->result;
    }
	
	function fwl_tokentx2($address,$startblock,$endblock,$latestblock,$page=0,$offset=0){
        $method = "fwl_tokentx";
		$params = $startblock.', "'.$endblock.'","'.$latestblock.'", "'.$address.'",'.$page.','.$offset;
        //$params = '{"startblock":'.$startblock.', "endblock":'.$endblock.', "address":"'.$address.'"}';
        $resp = $this->curl_data_block_result($method, $params,3);
        return $resp->result;
    }
	
	function fwl_getBlockReward($blockno){
        $method = "fwl_getBlockReward";
        $resp = $this->curl_data($method, $blockno,3);
        return $resp->result;
    }
	
	function fwl_getLogs($fromBlock,$toBlock,$address,$topic0){
        $method = "fwl_getLogs";
        $params = '{"fromBlock":"'.$fromBlock.'", "toBlock":"'.$toBlock.'", "address":"'.$address.'", "topics":["'.$topic0.'",null]}';
        $resp = $this->curl_data($method, $params);
        return $resp->result;
    }
	
	
    function fwl_getBlockByNumber($block_number, $detailed="true"){
        $method = "fwl_getBlockByNumber";
        $resp = $this->curl_data($method, $block_number, null, $detailed);
        return $resp["result"];
    }

    function fwl_getTransactionByHash($trx_hash){
        $method = "fwl_getTransactionByHash";
        $resp = $this->curl_data($method, $trx_hash);
        return $resp;
    }

    function fwl_getTransactionByBlockHashAndIndex($param1,$param2){
        $method = "fwl_getTransactionByBlockHashAndIndex";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method,$param);
        return $resp;
    }
    function fwl_getTransactionByBlockNumberAndIndex($param1,$param2){
        $method = "fwl_getTransactionByBlockNumberAndIndex";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method,$param);
        return $resp;
    }


    function fwl_getTransactionReceipt($trx_hash){
        $method = "fwl_getTransactionReceipt";
        $resp = $this->curl_data($method, $trx_hash);
        return $resp;
    }

   //function fwl_submitWork($nonce, $pow_hash, $mix_dig){
   //     $method = "fwl_submitWork";
   //     $param = $nonce.'", "'.$pow_hash.'", "'.$mix_dig;
   //     $resp = $this->curl_data($method, $param);
   //     return $resp["result"];
   // }

    //function fwl_submitHashrate($hash_rate, $ID_string){
    //    $method = "fwl_submitHashrate";
    //    $param = $hash_rate.'", "'.$ID_string;
    //    $resp = $this->curl_data($method,$param);
    //    return $resp["result"];
    //}

    function db_putString($DB_name, $key_name, $data){
        $method = "db_putString";
        $param = $DB_name.'", "'.$key_name.'", "'.$data;
        $resp = $this->curl_data($method, $param);
        return $resp["result"];
    }

    function db_getString($DB_name, $key_name){
        $method = "db_getString";
        $param = $DB_name.'", "'.$key_name;
        $resp = $this->curl_data($method, $param);
        return $resp["result"];
    }

    function db_putHex($DB_name, $key_name, $hex){
        $method = "db_putHex";
        $param = $DB_name.'", "'.$key_name.'", "'.$hex;
        $resp = $this->curl_data($method,$param);
        return $resp["result"];
    }

    function db_getHex($DB_name, $key_name){
        $method = "db_getHex";
        $param = $DB_name.'", "'.$key_name;
        $resp = $this->curl_data($method);
        return $resp["result"];
    }

    function shh_version(){
        $method = "shh_version";
        $resp = $this->curl_data($method);
        return $resp["result"];
    }

    function shh_newIdentity(){
        $method = "shh_newIdentity";
        $resp = $this->curl_data($method);
        return $resp["result"];
    }

    function shh_hasIdentity($new_ID_address){
        $method = "shh_hasIdentity";
        $resp = $this->curl_data($method, $new_ID_address);
        return $resp["result"];
    }

    function fwl_sendTransaction($from, $to, $value,  $gas="", $data_hex="", $gasPrice=""){
        $method = "fwl_sendTransaction";
        $params = '{"from":"'.$from.'", "to":"'.$to.'", "value":"0x'.dechex($value).'"';
        if(!empty($data_hex)) {
            $params .=', "data":"'.$data_hex.'"';
        }
        if(!empty($gas)) {
            $params .=', "gas":"0x'.dechex($gas).'"';
        }
        if(!empty($gasPrice)) {
            $params .=', "gasPrice":"'.$gasPrice.'"';
        }
        $params .= '}';
        $resp = $this->curl_data($method, $params);
        return $resp;
    }

    function fwl_call($from, $to, $value,  $gas="", $data_hex="", $gasPrice=""){
        $method = "fwl_call";
        $params = '{"from":"'.$from.'", "to":"'.$to.'", "value":"0x'.dechex($value).'"';
        if(!empty($data_hex)) {
            $params .=', "data":"'.$data_hex.'"';
        }
        if(!empty($gas)) {
            $params .=', "gas":"0x'.dechex($gas).'"';
        }
        if(!empty($gasPrice)) {
            $params .=', "gasPrice":"'.$gasPrice.'"';
        }
        $params .= '}';
        $resp = $this->curl_data($method, $params);
        return $resp;
    }

    function fwl_sendRawTransaction($data){
        $method = "fwl_sendRawTransaction";
        $resp = $this->curl_data($method, $data);
        return $resp;
	}


    function fwl_estimateGas($from, $to, $value,  $gas="", $data_hex="", $gasPrice=""){
        $method = "fwl_estimateGas";
        $params = '{"from":"'.$from.'", "to":"'.$to.'", "value":"0x'.dechex($value).'"';
        if(!empty($data_hex)) {
            $params .=', "data":"'.$data_hex.'"';
        }
        if(!empty($gas)) {
            $params .=', "gas":"0x'.dechex($gas).'"';
        }
        if(!empty($gasPrice)) {
            $params .=', "gasPrice":"'.$gasPrice.'"';
        }
        $params .= '}';
        $resp = $this->curl_data($method, $params);
        return $resp;
    }

    function fwl_newFilter($fromBlock, $toBlock, $address,  $topic1="", $topic2="",$topic3=""){
        $method = "fwl_newFilter";
        $params = '{"fromBlock":"'.$fromBlock.'", "toBlock":"'.$toBlock.'", "address":"'.$address;
        if(!empty($topic1)) {
            $params .=',topics":["'.$topic1.'"';
        }
        if(!empty($topic2)) {
            $params .=',"'.$topic2.'"';
        }
        if(!empty($topic3)) {
            $params .=',"'.$topic3.'"';
        }
        $params .= ']}';
        $resp = $this->curl_data($method, $params);
        return $resp;
    }

    function fwl_getWork(){
        $method = "fwl_getWork";
        $resp = $this->curl_data($method);
        return $resp;
    }
    function fwl_getCompilers(){
        $method = "fwl_getCompilers";
        $resp = $this->curl_data($method);
        return $resp;
    }
    function fwl_compileSolidity($data){
        $method = "fwl_compileSolidity";
        $resp = $this->curl_data($method, $data);
        return $resp;
    }
    function fwl_compileLLL($data){
        $method = "fwl_compileLLL";
        $resp = $this->curl_data($method, $data);
        return $resp;
    }
    function fwl_compileSerpent($data){
        $method = "fwl_compileSerpent";
        $resp = $this->curl_data($method, $data);
        return $resp;
    }

    function fwl_newBlockFilter(){
        $method = "fwl_newBlockFilter";
        $resp = $this->curl_data($method);
        return $resp;
    }

    function fwl_newPendingTransactionFilter(){
        $method = "fwl_newPendingTransactionFilter";
        $resp = $this->curl_data($method);
        return $resp;
    }
    function fwl_uninstallFilter($param1){
        $method = "fwl_uninstallFilter";
        $resp = $this->curl_data($method, $param1);
        return $resp;
    }
    function fwl_getFilterChanges($param1){
        $method = "fwl_getFilterChanges";
        $resp = $this->curl_data($method, $param1);
        return $resp;
    }
    function fwl_getFilterLogs($param1){
        $method = "fwl_getFilterLogs";
        $resp = $this->curl_data($method, $param1);
        return $resp;
    }

    function fwl_submitWork($param1="0x0",$param2="0x0",$param3="0x0"){
        $method = "fwl_submitWork";
        $param = $param1.'", "'.$param2.'", "'.$param3;
        $resp = $this->curl_data($method, $param);
        return $resp;
    }
    
    function fwl_submitHashrate($param1="0x0",$param2="0x0"){
        $method = "fwl_submitHashrate";
        $param = $param1.'", "'.$param2;
        $resp = $this->curl_data($method, $param);
        return $resp;
    }


    function web3_sha3($data_to_SHA3){
        $method = "web3_sha3";
        $resp = $this->curl_data($method, $data_to_SHA3);
        return $resp;
    }

    function shh_post($topics, $payload, $ttl=null, $priority=null, $from="", $to=""){
        $method = "shh_post";
        $params = '{"topics": '.$topics.', "payload":"'.$payload.'"';

        // TODO FIX Priority and TTL!!!!
        //, "priority": 0x'.dechex($priority);//. "ttl":0x'.dechex($ttl);//.', "priority": 0x'.dechex($priority).'';

        if(!empty($from)) {
            $params .=', "from":"'.$from.'"';
        }
        if(!empty($to)) {
            $params .=', "to":"0x'.$to.'"';
        }

        $params .= '}';
        $resp = $this->curl_data($method, $params);

        if(isset($resp->result)){
        	return $resp["result"];
        } else {
            return $resp["error"];
        }
    }


}
