/usr/bin/gethfw attach ipc:/node/node8001/geth.ipc << EOF 
var superaddr="0x3bded5f4d5edf7b72efde87be8b11a85f5f6fd78";
eth.defaultAccount=superaddr;
personal.unlockAccount(superaddr,"$5");
var _INITIAL_SUPPLY ="$3";
var _name ="$1";
var _symbol ="$2";
var _admin ="$4";
loadScript("./fb.js");
personal.lockAccount(superaddr);
admin.sleep(10);
var hash=fwb.transactionHash;
var prehash="fwbHash:";
console.log(prehash,hash);
eth.getTransactionReceipt(fwb.transactionHash);
EOF

