<?php
ini_set('display_errors',1);//when you are debuging ,pls set it to 1;else  set to 0
require_once('fwl.php');
$url =  "http://172.21.219.37";
$port = 8545;

function hex2str( $hex ) {
    return pack('H*', $hex);
}
function str2hex( $str ) {
    $unpacked = unpack('H*', $str);
    return array_shift($unpacked);
}

function getBlockNumber($address,$flag) {

$mongo   = new MongoDB\Driver\Manager('mongodb://127.0.0.1:27017');
$filter =  [ '$or' => [['from' => $address],
           ['to' => $address]]];

$options = array(    
	"sort" => array("blockNumber" => $flag,),
  "limit" => 1,
);

$query = new MongoDB\Driver\Query($filter, $options);
$rows = $mongo->executeQuery('blockDB.Transaction', $query);

foreach($rows as $r){   
     return $r->blockNumber;
}

return 0;

}

if(!isset($_GET["action"]))
{
echo '{"status":"0","message":"ERROR, usage: api?clientversion!","result":""}';
return 1;
}
//if parameter did not include "action", prompt error.

$flag=0;
$fwl = new fwl($url, $port);
$YourApiKeyToken="YourApiKeyToken";

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"clientversion")==0)
{
$flag=1;
$fwl->web3_clientVersion();
}

if(isset($_GET["data"]))
if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"sha3")==0)
{
$flag=1;
$data = $_GET["data"];
$fwl->web3_sha3(trim($data));
}

if((strcasecmp(preg_replace('/\s/','',$_GET["action"]),"version")==0)|| (strcasecmp(preg_replace('/\s/','',$_GET["action"]),"netid")==0) )
{
$flag=1;
$fwl->net_version();
}

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"listening")==0)
{
$flag=1;
$fwl->net_listening();
}

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"peercount")==0)
{
$flag=1;
$fwl->net_peerCount();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"protocolversion")==0) 
{
$flag=1;
$fwl->fwl_protocolVersion();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"syncing")==0) 
{
$flag=1;
$fwl->fwl_syncing();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"coinbase")==0) 
{
$flag=1;
$fwl->fwl_coinbase();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"mining")==0) 
{
$flag=1;
$fwl->fwl_mining();
}

if( (strcasecmp(preg_replace('/\s/','',$_GET["action"]),"hashrate")==0)||strcasecmp(preg_replace('/\s/','',$_GET["action"]),"gethashrate")==0)
{
$flag=1;
$fwl->fwl_hashrate();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"gasprice")==0) 
{
$flag=1;
$fwl->fwl_gasPrice();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"accounts")==0) 
{
$flag=1;
$fwl->fwl_accounts();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"blocknumber")==0) 
{
$flag=1;
$fwl->fwl_blockNumber();
}


if(isset($_GET["address"]))
if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"balance")==0)
{
	$address = $_GET["address"];
	$fwl->fwl_getBalance($address);

}


if( isset($_GET["address"]))
if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"balance")==0)
{
	$address = $_GET["address"];
	$fwl->fwl_getBalance($address);

}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getstorageat")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="";
if(isset($_GET["param3"]))
$param3=$_GET["param3"];
else
$param3="latest";

$flag=1;
$fwl->fwl_getStorageAt($param1,$param2,$param3);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"gettransactioncount")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="latest";

$flag=1;
$fwl->fwl_getTransactionCount($param1,$param2);
}


if( isset($_GET["param"]))
if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getblocktransactioncountbyhash")==0)
{
	$param = $_GET["param"];
	$flag=1;
	$fwl->fwl_getBlockTransactionCountByHash($param);
}

if( isset($_GET["param"]))
if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getblocktransactioncountbynumber")==0) 
{
	$param = $_GET["param"];
	$flag=1;
	$fwl->fwl_getBlockTransactionCountByNumber($param);
}

if( isset($_GET["param"]))
if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getunclecountbyblockhash")==0)
{
	$param = $_GET["param"];
	$flag=1;
	$fwl->fwl_getUncleCountByBlockHash($param);
}

if( isset($_GET["param"]))
if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getunclecountbyblocknumber")==0) 
{
	$param = $_GET["param"];
	$flag=1;
	$fwl->fwl_getUncleCountByBlockNumber($param);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getCode")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="latest";

$flag=1;
$fwl->fwl_getCode($param1,$param2);
}


if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"sign")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="";

$flag=1;
$fwl->fwl_sign($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"sendTransaction")==0) 
{
if(isset($_GET["from"]))
$from=$_GET["from"];
else
$from="";
if(isset($_GET["to"]))
$to=$_GET["to"];
else
$to="";

if(isset($_GET["value"]))
$value=$_GET["value"];
else
$value="";

if(isset($_GET["gas"]))
$gas=$_GET["gas"];
else
$gas="";

if(isset($_GET["data_hex"]))
$data_hex=$_GET["data_hex"];
else
$data_hex="";

if(isset($_GET["gasprice"]))
$gasprice=$_GET["gasprice"];
else
$gasprice="";

$flag=1;
$fwl->fwl_sendTransaction($from, $to, $value,  $gas, $data_hex, $gasprice);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"newFilter")==0) 
{
if(isset($_GET["fromBlock"]))
$fromBlock=$_GET["fromBlock"];
else
$fromBlock="latest";

if(isset($_GET["toBlock"]))
$toBlock=$_GET["toBlock"];
else
$toBlock="latest";

if(isset($_GET["address"]))
$address=$_GET["address"];
else
$address="";

if(isset($_GET["topic1"]))
$topic1=$_GET["topic1"];
else
$topic1="";

if(isset($_GET["topic2"]))
$topic2=$_GET["topic2"];
else
$topic2="";

if(isset($_GET["topic3"]))
$topic3=$_GET["topic3"];
else
$topic3="";

$flag=1;
$fwl->fwl_newFilter($fromBlock, $toBlock, $address,  $topic1, $topic2, $topic3);

}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"call")==0) 
{
if(isset($_GET["from"]))
$from=$_GET["from"];
else
$from="";
if(isset($_GET["to"]))
$to=$_GET["to"];
else
$to="";

if(isset($_GET["value"]))
$value=$_GET["value"];
else
$value="";

if(isset($_GET["gas"]))
$gas=$_GET["gas"];
else
$gas="";

if(isset($_GET["data_hex"]))
$data_hex=$_GET["data_hex"];
else
$data_hex="";

if(isset($_GET["gasprice"]))
$gasprice=$_GET["gasprice"];
else
$gasprice="";

$flag=1;
$fwl->fwl_call($from, $to, $value,  $gas, $data_hex, $gasprice);
}

if( isset($_GET["data"]))
if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"sendRawTransaction")==0) 
{
	$param = $_GET["data"];
	$flag=1;
	$fwl->fwl_sendRawTransaction($param);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"estimateGas")==0) 
{
if(isset($_GET["from"]))
$from=$_GET["from"];
else
$from="";
if(isset($_GET["to"]))
$to=$_GET["to"];
else
$to="";

if(isset($_GET["value"]))
$value=$_GET["value"];
else
$value="";

if(isset($_GET["gas"]))
$gas=$_GET["gas"];
else
$gas="";

if(isset($_GET["data_hex"]))
$data_hex=$_GET["data_hex"];
else
$data_hex="";

if(isset($_GET["gasprice"]))
$gasprice=$_GET["gasprice"];
else
$gasprice="";

$flag=1;
$fwl->fwl_estimateGas($from, $to, $value,  $gas, $data_hex, $gasprice);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getBlockByHash")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="true";

$flag=1;
$fwl->fwl_getBlockByHash($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getBlockByNumber")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="true";

$flag=1;
$fwl->fwl_getBlockByNumber($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getTransactionByHash")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_getTransactionByHash($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getTransactionByBlockHashAndIndex")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="0x0";

$flag=1;
$fwl->fwl_getTransactionByBlockHashAndIndex($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getTransactionByBlockNumerAndIndex")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="0x0";

$flag=1;
$fwl->fwl_getTransactionByBlockNumerAndIndex($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getTransactionReceipt")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_getTransactionReceipt($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getUncleByBlockHashAndIndex")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="latest";

$flag=1;
$fwl->fwl_getUncleByBlockHashAndIndex($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getUncleByBlockNumberAndIndex")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="latest";

$flag=1;
$fwl->fwl_getUncleByBlockNumberAndIndex($param1,$param2);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getCompilers")==0) 
{
$flag=1;
$fwl->fwl_getCompilers();
}


if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"compileSolidity")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_compileSolidity($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"compileLLL")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_compileLLL($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"compileSerpent")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_compileSerpent($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"newBlockFilter")==0) 
{
$flag=1;
$fwl->fwl_newBlockFilter();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"newPendingTransactionFilter")==0) 
{
$flag=1;
$fwl->fwl_newPendingTransactionFilter();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"uninstallFilter")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_uninstallFilter($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getFilterChanges")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_getFilterChanges($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getFilterLogs")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="";

$flag=1;
$fwl->fwl_getFilterLogs($param1);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getWork")==0) 
{
$flag=1;
$fwl->fwl_getWork();
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"submitWork")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="0x0";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="0x0";
if(isset($_GET["param3"]))
$param3=$_GET["param3"];
else
$param3="0x0";

$flag=1;
$fwl->fwl_submitWork($param1,$param2,$param3);
}

if( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"submitHashrate")==0) 
{
if(isset($_GET["param1"]))
$param1=$_GET["param1"];
else
$param1="0x0";
if(isset($_GET["param2"]))
$param2=$_GET["param2"];
else
$param2="0x0";

$flag=1;
$fwl->fwl_submitHashrate($param1,$param2);
}

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"status")==0) 
{
$flag=1;
$fwl->txpool_status();
}

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"content")==0) 
{
$flag=1;
$fwl->txpool_status();
}

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"inspect")==0) 
{
$flag=1;
$fwl->txpool_inspect();
}

if( isset($_GET["address"]))
if((strcasecmp(preg_replace('/\s/','',$_GET["action"]),"setfwlbase")==0) )
{
	$flag =1;	
	$address = $_GET["address"];
	$fwl->miner_setFwlBase($address);
}

if( isset($_GET["keydata"]) && isset($_GET["passphrase"]) )
if(
 strcasecmp(preg_replace('/\s/','',$_GET["action"]),"newaccount")==0)
{
$flag=1;
$key = $_GET["keydata"];
$pass = $_GET["passphrase"];
$fwl->personal_importRawKey($key,$pass);
}

if( isset($_GET["key"]))
if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"newaccount")==0)
{
$flag=1;
$key = $_GET["key"];
$fwl->personal_newAccount($key);
}
if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"listaccounts")==0) 
{
	$flag =1;	
$fwl->personal_listAccounts();
}

if( isset($_GET["address"]) && isset($_GET["key"]) )
if(( strcasecmp(preg_replace('/\s/','',$_GET["action"]),"lockaccount")==0) && 
  (strcasecmp($_GET["apikey"],"YourApiKeyToken")==0) && 
    strlen($_GET["address"])>0 && strlen($_GET["key"])>0)
{
	$flag =1;	
$address = $_GET["address"];
$key =$_GET["key"];
$fwl->personal_lockAccount($address,$key);
}

if( isset($_GET["address"]) && isset($_GET["key"]) )
if((strcasecmp(preg_replace('/\s/','',$_GET["action"]),"unlockaccount")==0)  && strlen($_GET["address"])>0 && strlen($_GET["key"])>0)
{
	$flag =1;	
$address = $_GET["address"];
$key =$_GET["key"];
$fwl->personal_unlockAccount($address,$key);
}

if( isset($_GET["action"])     && isset($_GET["address"])     && isset($_GET["startblock"])     && isset($_GET["endblock"])   )
if((  strcasecmp(preg_replace('/\s/','',$_GET["action"]),"txlist")==0))
{
$flag =1;	
$address = $_GET["address"];
$startblock = $_GET["startblock"];
$endblock = $_GET["endblock"];
if(isset($_GET["page"])) {
$page = $_GET["page"];
}
else
{
  $page = 0;
}
if(isset($_GET["offset"])) {
$offset = $_GET["offset"];
} 
else
{
$offset = 0;
}

if($endblock != "latest")
{
	$endblock = "0x".dechex($endblock);
}

if($startblock == 0 ) {
	$startblock = getBlockNumber($address,1); // 1 lowest -1 highest
}

$fwl->fwl_txlist($address,$startblock,$endblock,"latest",$page,$offset);

}

if( 
    isset($_GET["address"]) 
    && isset($_GET["startblock"]) 
    && isset($_GET["endblock"]) 
  )
if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"tokentx")==0)
{
$address = $_GET["address"];
$startblock = $_GET["startblock"];
$endblock = $_GET["endblock"];
if(isset($_GET["page"])) {
$page = $_GET["page"];
}
else
{
  $page = 0;
}
if(isset($_GET["offset"])) {
$offset = $_GET["offset"];
} 
else
{
$offset = 0;
}

if($startblock == 0 ) {
	$startblock = getBlockNumber($address,1); // 1 lowest -1 highest
}

if($endblock != "latest")
{
	$endblock = "0x".dechex($endblock);
}

$fwl->fwl_tokentx($address,$startblock,$endblock,"latest",$page,$offset);
$flag =1;
}

if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getblockreward")==0)
{
$blockno = $_GET["blockno"];
$fwl->fwl_getBlockReward($blockno);
$flag = 1;
}

if( isset($_GET["fromBlock"])&& isset($_GET["toBlock"])&& isset($_GET["address"])&& isset($_GET["topic0"])  )
if(strcasecmp(preg_replace('/\s/','',$_GET["action"]),"getLogs")==0)
{
$flag = 1;
$fromBlock = $_GET["fromBlock"];
$toBlock = $_GET["toBlock"];
$address = $_GET["address"];
$topic0 = $_GET["topic0"];
$fwl->fwl_getLogs($fromBlock,$toBlock,$address,$topic0);
}

if($flag==0)
{
echo '{"status":"0","message":"function no founded","result":""}';
return 1;
}

?>
