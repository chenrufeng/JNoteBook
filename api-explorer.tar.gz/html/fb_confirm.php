<!DOCTYPE html>
<?php
$firsttime="0";
$tokenname = $tokensymbol = $tokensupply = $adminaccount = $superkey = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $tokenname = test_input($_POST["tokenname"]);
   $tokensymbol = test_input($_POST["tokensymbol"]);
   $tokensupply = test_input($_POST["tokensupply"]);
   $_tokensupply= $tokensupply."000000000000000000";
   $adminaccount = test_input($_POST["adminaccount"]);
   $superkey = test_input($_POST["superkey"]);
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>

<?php

exec("sh /var/www/html/fb.sh \"$tokenname\" \"$tokensymbol\" \"$_tokensupply\" \"$adminaccount\" \"$superkey\"",$res);
$fwbhash="";
$fwbaddr="";
foreach($res as $key=>$value)
{
if(strpos($value,"fwbHash:")!==false)
  {
   if(preg_match('/0x(.*?)$/',$value,$match))
       $fwbhash=$match[0];
   } 
if(strpos($value,"contractAddress: ")!==false)
   {
    if(preg_match('/\"(.*?)\"/',$value,$match))
	   $fwbaddr=$match[0];
    }
}
?>


  <head>
    <meta content="origin-when-cross-origin" name="referrer" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>CREATE TOKEN</title>

    <link rel="stylesheet" media="all" href="token.css" />

  <script>sso.init = "username_recovery/new"</script>
<script language="javascript">

function custom_close(){
  if (confirm("您确定要关闭本页吗？"))
    {window.opener=null;
      window.open('','_self');
      window.close();}
      else{}
    }

</script>


  </head>
  <body>
    <div class="header">
        <div class="head-con m-warp">创建TOKEN/CREATE TOKEN</div>
    </div>

    
<?php if(strlen($fwbhash)==0 || strlen($fwbaddr)==0): ?>
    <div class="confirm-box content active m-warp sss">
    <div class="confirm-con m-wars w700">
        <div class="titile">抱歉！创建TOKEN失败</div>
        <div class="confirm-decs" style="">请用HASH重新查询部署情况或重新提交参数！</div>
        <div class="confirm-form-box">
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN合约哈希：</span>
                <span class="confirm-item-con name">没生成正确的HASH值</span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">部署合约地址：</span>
                <span class="confirm-item-con symbol">没获得正确的合约地址</span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN名称：</span>
                <span class="confirm-item-con supply"><?php  echo $tokenname; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN简称:</span>
                <span class="confirm-item-con password"><?php  echo $tokensymbol; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN数量：</span>
                <span class="confirm-item-con supply"><?php  echo $tokensupply; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">管理地址：</span>
                <span class="confirm-item-con account"><?php  echo $adminaccount; ?></span>
            </div>
            <div class="btbt">
            <a class="confirm-btn cancel" href="/fb.php">重新创建TOKEN</a>
              <div class="confirm-btn" onclick="custom_close();">确认已经记录以上信息并关闭窗口！</div>
            </div>
        </div>
    </div>
    </div>
<?php else: ?>
    <div class="confirm-box content active m-warp sss">
    <div class="confirm-con m-wars w700">
        <div class="titile">恭喜！创建TOKEN成功</div>
        <div class="confirm-decs" style="">请记录如下token的信息尤其保存好合约地址！ </div>
        <div class="confirm-form-box">
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN合约哈希：</span>
                <span class="confirm-item-con name">"<?php  echo $fwbhash; ?>"</span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">部署合约地址：</span>
                <span class="confirm-item-con symbol"><?php  echo $fwbaddr; ?></span>
               <?php 
 //              if(strlen($fwbhash)>0 && strlen($fwbaddr)==0) {
 //                  echo       "<br> <span class=\"confirm-item-title\"> <a href=\"./fb_getaddr.php?hash=".$fwbhash."\">稍后点击这个链接进行查询</a></span>";
 //                }?>
                 <br><span class="confirm-item-title"> <a href="./fb_getaddr.php?hash=<?php  echo $fwbhash; ?>">如果没有获得合约地址，请稍后点击这个链接进行查询。</a></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN名称：</span>
                <span class="confirm-item-con supply"><?php  echo $tokenname; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN简称：</span>
                <span class="confirm-item-con password"><?php  echo $tokensymbol; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">TOKEN数量：</span>
                <span class="confirm-item-con supply"><?php  echo $tokensupply; ?></span>
            </div>
            <div class="confirm-item">
                <span class="confirm-item-title">管理地址：</span>
                <span class="confirm-item-con account"><?php  echo $adminaccount; ?></span>
            </div>
            <div class="confirm-decs">请认真保存以上信息，通过钱包在管理地址上可以查看创建的Token总额！</div>
            <div class="btbt">
            <a class="confirm-btn j-cancel cancel" href="/fb.php">再创建一个TOKEN</a>
              <div class="confirm-btn " onclick="custom_close();">确认已经记录以上信息！并关闭窗口</div>
            </div>
        </div>
    </div>
    </div>
<?php endif; ?>
  
<!--     <div class="footer m-warp">
        <p>京ICP备11017824号-4 / 京ICP证130164号 北京市公安局朝阳分局备案编号:110105000501</p>
        <p>Copyright © 2016-2017 Fanwe 中文 English</p>
    </div> -->

</body>
</html>
