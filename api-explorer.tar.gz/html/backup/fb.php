<!DOCTYPE html>
    <?php
// define variables and set to empty values
// 
$firsttime="0";
$tokenname = $tokensymbol = $tokensupply = $adminaccount = $superkey = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $tokenname = test_input($_POST["tokenname"]);
   $tokensymbol = test_input($_POST["tokensymbol"]);
   $tokensupply = test_input($_POST["tokensupply"]);
   $adminaccount = test_input($_POST["adminaccount"]);
   $superkey = test_input($_POST["superkey"]);
   $firsttime = test_input($_POST["firsttime"]);
   $confirm = test_input($_POST["comfirm"]);
}

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}
?>
  <head>
    <meta content="origin-when-cross-origin" name="referrer" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>CREATE TOKEN</title>

    <link rel="stylesheet" media="all" href="token.css" />
  </head>
  <body>
    

    <div class="topbar">
  <div class="page">
    <div class="topbar-container">
      <a class="topbar-logo topbar-logo-envato" ></a><h1><font face="verdana" color="#F8F8FF">创建TOKEN/CREATE T0KEN</font></h1>

      <div class="topbar-content">
        

      </div>
    </div>
  </div>
</div>


    <div class="page">
      
      <div role="main" class="main">
        

<div class="box-center-form">
  

    <?php
      if(strcmp($firsttime,"0")==0)
      {
           echo       " <h1 class=\"box-heading\">创建TOKEN</h1><p>请输入创建token的参数. </p>";
           
           echo        "<form class=\"new_username_recovery\" id=\"form1\" action=\"./fb.php\" accept-charset=\"UTF-8\" method=\"post\">";
           echo       " <font color=\"red\"><label type=\"text\" name=\"info\" id=\"info\" value=\"\" /></font>";
      }
    else
      {
           echo       " <h1 class=\"box-heading\">再次确认!</h1><p>请仔细检查输入的参数: </p>";
           echo        "<form class=\"new_username_recovery\" id=\"form1\" action=\"./fb_confirm.php\" accept-charset=\"UTF-8\" method=\"post\">";
      }
    ?>




     <?php
      if(strcmp($firsttime,"0")==0)
         echo "<input type=\"hidden\" name=\"firsttime\" value=\"1\" />";
    else
         echo "<input type=\"hidden\" name=\"firsttime\" value=\"0\" />";
    ?>



    <div class="input-group ill-input">
    <?php
      if(strcmp($firsttime,"0")==0)
      echo  "TOKEN名称/Token Name:<input type=\"text\" name=\"tokenname\" id=\"tokenname\" />";
    else
    {
      echo "TOKEN名称:".$tokenname;
      echo "<input type=\"hidden\" name=\"tokenname\" id=\"tokenname\" value=\"$tokenname\" />";
    }
    ?>
    </div>

    <div class="input-group ill-input">
       <?php
      if(strcmp($firsttime,"0")==0)
      echo  "TOKEN简称/Token Symbol:<input type=\"text\" name=\"tokensymbol\" id=\"tokensymbol\" />";
    else
    {
      echo "TOKEN简称:".$tokensymbol;
          echo "<input type=\"hidden\" name=\"tokensymbol\" id=\"tokensymbol\" value=\"$tokensymbol\" />";
    }
    ?>
    </div>

    <div class="input-group ill-input">
    <?php
      if(strcmp($firsttime,"0")==0)
      echo  "TOKEN数量/Token Supply:<input type=\"text\" name=\"tokensupply\" id=\"tokensupply\" />";
    else
    {
      echo "TOKEN数量:".$tokensupply;
                echo "<input type=\"hidden\" name=\"tokensupply\" id=\"tokensupply\" value=\"$tokensupply\" />";
    }

    ?>
    </div>

   <div class="input-group ill-input">
    <?php
      if(strcmp($firsttime,"0")==0)
      echo  "管理地址/Admin Account:<input type=\"text\" name=\"adminaccount\" id=\"adminaccount\" />";
    else
    {
      echo "管理地址:".$adminaccount;
                      echo "<input type=\"hidden\" name=\"adminaccount\" id=\"adminaccount\" value=\"$adminaccount\" />";
    }
    ?>
    </div>

   <div class="input-group ill-input">
      <?php
      if(strcmp($firsttime,"0")==0)
      echo  "超级密钥/Super Password:<input type=\"password\" name=\"superkey\" id=\"superkey\" />";
    else
    {
      echo "超级口令:**************";
      echo "<input type=\"hidden\" name=\"superkey\" id=\"superkey\" value=\"$superkey\" />";
    }
    ?>
    </div>


    <?php
      if(strcmp($firsttime,"0")==0)
      echo  "<input type=\"submit\" name=\"commit\" value=\"确认提交/Comfirm\" />";
    else
    {
    echo "<input type=\"submit\" name=\"Cancel\" value=\"取消/Cancel\" data-disable-with=\"Cancel\" onclick=\"go.history(-1);\"/><br><br>";


    echo "<input type=\"hidden\" name=\"comfirm\" value=\"yes\" />";
    echo "<input type=\"submit\" name=\"commit\" value=\"再确认并创建/Comfirm&Create Token\" />";
    }
    ?>



</form></div>
      </div>


<hr>
    </div>

  
    

  </body>
  <script type="text/javascript">
          function submitTest(){
          var tokenname = document.form1.tokenname.value;
          var tokensymbol = document.form1.tokensymbol.value;
          var tokensupply = document.form1.tokensupply.value;
          var adminaccount = document.form1.adminaccount.value;
          var superkey = document.form1.superkey.value;

          var checkNum = /^[0-9]\d+$/;
          var checkAddr = /^0x[0-9A-Fa-f]\d+$/;

          if(tokenname=="" || tokensymbol=="" || tokensupply =="" || adminaccount=="" || superkey=="" ){
          alert("输入框的内容不能为空");
          return false;
          }

          if(!checkNum.test(tokensupply)){
          alert('【数量字段】输入格式错误，只能数字（例如：12233333000000000）！！！');
                          return false;
          }
          if(!checkAddr.test(adminaccount)){
          alert('【管理地址】输入格式错误，只能数字（例如：12233333000000000）！！！');
                          return false;
          }
          return true;
          }

            function validSupply()
            {
                var checkNum = /^[0-9]\d+$/;
                var x=document.getElementsByName('tokensupply');
                if(!checkNum.test(x)){
                   document.getElementsByName('info').value="输入的TOKEN数值有误，请修改！"
                   document.getElementsByName('tokensupply').value="";
                }
                else
                {
                    alert("hello");
                }
            }

 </script>
</html>
